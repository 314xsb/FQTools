// ==UserScript==
// @name         Youtube自动选择中文翻译字幕
// @namespace    http://tampermonkey.net/
// @version      2.4
// @description  Youtube自动点击中文翻译字幕
// @author       大奶瓜
// @match        https://www.youtube.com/*
// @require      https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js
// @grant        none
// ==/UserScript==

(() => {
    const translate = () => {
        const onLoadStart = () => {
            const clickActive = (clickBtn, role = "menuitemradio") => {
                const theNode = $(`[role=${role}]:contains(${clickBtn})`)
                theNode.length ? theNode.click() : ''
            }
            const ccBtnT = $('.ytp-subtitles-button[aria-pressed="true"][style=""]')
            const ccBtnF = $('.ytp-subtitles-button[aria-pressed="false"][style=""]')
            if (!(ccBtnT.length + ccBtnF.length)) return
            ccBtnF.click()
            $('.ytp-settings-button').click()
            clickActive("字幕", "menuitem")
            clickActive("中文（简体）")
            clickActive("中文（中国）")
            clickActive("自动翻译")
            clickActive("中文（简体）")
        }
        $('video').on('loadstart', onLoadStart).trigger('loadstart')
    }
    translate()
    const intervalNum = setInterval(()=>{
        const videoNode = document.querySelector('video')
        if (videoNode) {
            videoNode.addEventListener('resize', () => { console.log('resize');translate() },{once:true})
            clearInterval(intervalNum)
        }
    },500)
})()
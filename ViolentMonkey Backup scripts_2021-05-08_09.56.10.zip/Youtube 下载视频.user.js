// ==UserScript==
// @name                Youtube: Download Video
// @name:zh-TW          Youtube 下載影片
// @name:zh-CN          Youtube 下载视频
// @name:ja             Youtube ビデオをダウンロード
// @name:ko             Youtube 비디오 다운로드
// @name:ru             Youtube Скачать видео
// @version             1.0.3
// @description         One button click to direct video download web page.
// @description:zh-TW   即按前往下載影片的網頁。
// @description:zh-CN   一键导向下载视频的网页。
// @description:ja      ボタンをクリックして、ビデオのダウンロードWebページに移動します。
// @description:ko      한 번의 클릭으로 비디오 다운로드 웹 사이트를 탐색하십시오.
// @description:ru      Нажмите кнопку, чтобы перейти на страницу загрузки видео.
// @author              Hayao-Gai
// @namespace           https://github.com/HayaoGai
// @icon                https://upload.wikimedia.org/wikipedia/commons/4/4c/YouTube_icon.png
// @match               https://www.youtube.com/*
// @grant               none
// ==/UserScript==

/* jshint esversion: 6 */

(function() {
    'use strict';

    const textStyle = `
.download-button {
    background-color: var(--yt-spec-10-percent-layer);
    color: var(--yt-spec-text-secondary);
    border-radius: 2px;
    padding: var(--yt-button-padding);
    margin: auto var(--ytd-subscribe-button-margin, 4px);
    white-space: nowrap;
    font-size: var(--ytd-tab-system_-_font-size);
    font-weight: var(--ytd-tab-system_-_font-weight);
    letter-spacing: var(--ytd-tab-system_-_letter-spacing);
    text-transform: var(--ytd-tab-system_-_text-transform);
    display: flex;
    flex-direction: row;
    cursor: pointer;
}
.download-text {
    --yt-formatted-string-deemphasize-color: var(--yt-spec-text-secondary);
    --yt-formatted-string-deemphasize_-_margin-left: 4px;
    --yt-formatted-string-deemphasize_-_display: initial;
}`;
    let currentUrl = document.location.href;
    let isPlaylist = currentUrl.includes("playlist");

    css();

    init(10);

    locationChange();

    function init(times) {
        for (let i = 0; i < times; i++) {
            setTimeout(delButton, 500 * i);
            setTimeout(findPanel, 500 * i);
        }
    }

    function delButton() {
        if (!isPlaylist) return;
        document.querySelectorAll("#analytics-button.download-panel").forEach(panel => {
            panel.classList.remove("download-panel");
            panel.querySelector(".download-button").remove();
        });
    }

    function findPanel() {
        if (isPlaylist) return;
        document.querySelectorAll("#analytics-button:not(.download-panel)").forEach(panel => {
            panel.classList.add("download-panel");
            addButton(panel);
        });
    }

    function addButton(panel) {
        // button
        const button = document.createElement("div");
        button.classList.add("download-button");
        button.addEventListener("click", onClick);
        // text
        const text = document.createElement("span");
        text.classList.add("download-text");
        text.innerHTML = getLocalization();
        // append
        panel.insertBefore(button, panel.firstElementChild);
        button.appendChild(text);
    }

    function onClick() {
        const url = document.location.href.replace("youtube", "youtubeto");
        window.open(url);
    }

    function getLocalization() {
        switch (document.querySelector("html").lang) {
            case "zh-Hant-TW":
                return "下載";
            case "zh-Hant-HK":
                return "下載";
            case "zh-Hans-CN":
                return "下载";
            case "ja-JP":
                return "ダウンロード";
            case "ko-KR":
                return "다운로드";
            case "ru-RU":
                return "Скачать вниз";
            default:
                return "DOWNLOAD";
        }
    }

    function css() {
        const style = document.createElement("style");
        style.type = "text/css";
        style.innerHTML = textStyle;
        document.head.appendChild(style);
    }

    function locationChange() {
        const observer = new MutationObserver(mutations => {
            mutations.forEach(() => {
                if (currentUrl !== document.location.href) {
                    currentUrl = document.location.href;
                    isPlaylist = currentUrl.includes("playlist");
                    init(10);
                }
            });
        });
        const target = document.body;
        const config = { childList: true, subtree: true };
        observer.observe(target, config);
    }

})();

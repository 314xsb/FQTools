// ==UserScript==
// @name         Youtube Video Converter | MP3,MP4
// @name Youtube Video Converter | MP3,MP4
// @name:pt-BR Youtube Video Converter | MP3,MP4
// @name:ar Youtube Video Converter | MP3,MP4
// @name:bg Youtube Video Converter | MP3,MP4
// @name:cs Youtube Video Converter | MP3,MP4
// @name:da Youtube Video Converter | MP3,MP4
// @name:de Youtube Video Converter | MP3,MP4
// @name:el Youtube Video Converter | MP3,MP4
// @name:eo Youtube Video Converter | MP3,MP4
// @name:es Youtube Video Converter | MP3,MP4
// @name:fi Youtube Video Converter | MP3,MP4
// @name:fr Youtube Video Converter | MP3,MP4
// @name:fr-CA Youtube Video Converter | MP3,MP4
// @name:he Youtube Video Converter | MP3,MP4
// @name:hu Youtube Video Converter | MP3,MP4
// @name:id Youtube Video Converter | MP3,MP4
// @name:it Youtube Video Converter | MP3,MP4
// @name:ja Youtube Video Converter | MP3,MP4
// @name:ko Youtube Video Converter | MP3,MP4
// @name:nb Youtube Video Converter | MP3,MP4
// @name:nl Youtube Video Converter | MP3,MP4
// @name:pl Youtube Video Converter | MP3,MP4
// @name:ro Youtube Video Converter | MP3,MP4
// @name:ru Youtube Video Converter | MP3,MP4
// @name:sk Youtube Video Converter | MP3,MP4
// @name:sr Youtube Video Converter | MP3,MP4
// @name:sv Youtube Video Converter | MP3,MP4
// @name:th Youtube Video Converter | MP3,MP4
// @name:tr Youtube Video Converter | MP3,MP4
// @name:uk Youtube Video Converter | MP3,MP4
// @name:vi Youtube Video Converter | MP3,MP4
// @name:zh-CN Youtube Video Converter | MP3,MP4
// @name:zh-TW Youtube Video Converter | MP3,MP4
// @namespace    http://tampermonkey.net/
// @version      0.5
// @description  a basic youtube video converter, fastest, one click!
// @description:pt-BR um conversor de vídeo do YouTube básico, mais rápido, com um clique!
// @description:ar محول فيديو يوتيوب أساسي ، أسرع ، بنقرة واحدة!
// @description:bg основен youtube видео конвертор, най-бърз, с едно кликване!
// @description:cs základní převodník videa z YouTube, nejrychlejší, jedno kliknutí!
// @description:da en grundlæggende youtube-videokonverter, hurtigst med et enkelt klik!
// @description:de Ein einfacher YouTube-Videokonverter, am schnellsten, mit einem Klick!
// @description:el ένας βασικός μετατροπέας βίντεο youtube, πιο γρήγορα, με ένα κλικ!
// @description:eo baza jutuba video-konvertilo, plej rapida, unu klako!
// @description:es un convertidor de video básico de youtube, más rápido, ¡con un clic!
// @description:fi Voit ladata youtube-videoita helposti tällä laajennuksella, nopeimmin käytetyllä muuntimella. tekemä doktoburu.
// @description:fr un convertisseur vidéo basique sur youtube, le plus rapide, en un clic!
// @description:fr-CA un convertisseur vidéo basique sur youtube, le plus rapide, en un clic!
// @description:he אתה יכול להוריד בקלות סרטוני יוטיוב עם הרחבה זו, הממיר המהיר ביותר בשימוש. תוצרת doktoburu.
// @description:hu egyszerűen letöltheti a YouTube videókat ezzel a kiterjesztéssel, a leggyorsabban használt konverterrel. doktoburu készítette.
// @description:id Anda dapat dengan mudah mengunduh video youtube dengan ekstensi ini, pengonversi tercepat yang digunakan. dibuat dengan doktoburu.
// @description:it Puoi scaricare facilmente i video di YouTube con questa estensione, il convertitore più veloce da usare. fatto con doktoburu.
// @description:ja 使用する最速のコンバーターであるこの拡張機能を使用して、YouTubeビデオを簡単にダウンロードできます。 ドクトブルで作られました。
// @description:ko 가장 빠른 변환기 인이 확장 프로그램을 사용하여 YouTube 비디오를 쉽게 다운로드 할 수 있습니다. 독토 부루로 만든.
// @description:nb Du kan enkelt laste ned youtube-videoer med denne utvidelsen, den raskeste omformeren å bruke. laget med doktoburu.
// @description:nl Je kunt eenvoudig YouTube-video's downloaden met deze extensie, de snelste converter die je kunt gebruiken. gemaakt met doktoburu.
// @description:pl Możesz łatwo pobierać filmy z YouTube'a za pomocą tego rozszerzenia, najszybszego konwertera w użyciu. wykonane z doktoburu.
// @description:ro Puteți descărca cu ușurință videoclipuri YouTube cu această extensie, cel mai rapid convertor de utilizat. realizat cu doktoburu.
// @description:ru базовый видео конвертер YouTube, самый быстрый, в один клик!
// @description:sk S týmto rozšírením, najrýchlejším prevodníkom, ktorý môžete použiť, môžete ľahko sťahovať videá z youtube. vyrobené s doktoburu.
// @description:sr Помоћу овог наставка, најбржег конвертера за употребу, лако можете преузети ИоуТубе видео записе. направљен доктобуру.
// @description:sv Du kan enkelt ladda ner youtube-videor med den här förlängningen, den snabbaste konverteraren att använda. gjord med doktoburu.
// @description:th คุณสามารถดาวน์โหลดวิดีโอ youtube ได้อย่างง่ายดายด้วยส่วนขยายนี้ซึ่งเป็นตัวแปลงที่เร็วที่สุดในการใช้งาน ทำด้วย doktoburu
// @description:tr basit bir youtube video dönüştürücü, en hızlısı bu, tek tıklama ile mp3 ve mp4 indirebilirsin!
// @description:uk базовий відеоконвертер YouTube, найшвидший, в один клік!
// @description:vi Bạn có thể dễ dàng tải video youtube bằng tiện ích mở rộng này, công cụ chuyển đổi nhanh nhất để sử dụng. làm bằng doktoburu.
// @description:zh-CN 您可以轻松下载具有此扩展程序的youtube视频，这是使用速度最快的转换器。 用doktoburu制成。
// @description:zh-TW 您可以轻松下载具有此扩展程序的youtube视频，这是使用速度最快的转换器。 用doktoburu制成。
// @author       doktoburu
// @match        *://www.youtube.com/*
// @icon         https://www.google.com/s2/favicons?domain=youtube.com
// @grant        none
// ==/UserScript==

(function () {
    var isFullscreen = false;
    var fullscreenButton = document.getElementsByClassName("ytp-fullscreen-button ytp-button")[0];
    fullscreenButton.onclick = function () {
        if (isFullscreen == false) {
            document.querySelector("#esmanur").remove();
            isFullscreen = true;
        } else if (isFullscreen == true) {
            createButton();
            isFullscreen = false;
        }
    };

    function urlCut(url) {
        var regExp = /^.*((youtu.be\/)|(v\/)|(\/u\/\w\/)|(embed\/)|(watch\?))\??v?=?([^#\&\?]*).*/;
        var match = String(url).match(regExp);
        return match && match[7].length == 11 ? match[7] : false;
    }
    var isCreated;
    setInterval(function () {
        if (document.URL == "https://www.youtube.com/" || document.URL == "http://www.youtube.com/") {
            document.querySelector("#esmanur").remove();
            isCreated = false;
        }
        if (document.URL.indexOf("watch?v=") > 1 && isCreated == false && isFullscreen == false) {
            createButton();
            isCreated = true;
        }
    }, 1);

    function createButton() {
        var convertButton = document.createElement("div");
        var downloadText = document.createElement("p");
        convertButton.id = "esmanur";
        convertButton.style.padding = "16px";
        convertButton.style.position = "fixed";
        convertButton.style.backgroundColor = "red";
        convertButton.style.zIndex = "10000";
        convertButton.style.top = "91vh";
        convertButton.style.right = "2vw";
        convertButton.style.transition = "all 0.6s";
        convertButton.style.borderRadius = "16px";
        convertButton.style.boxShadow = "rgba(0, 0, 0, 0.35) 0px 5px 15px";
        convertButton.style.cursor = "pointer";
        downloadText.textContent = "DOWNLOAD";
        downloadText.style.color = "white";
        downloadText.style.fontSize = "25px";

        convertButton.onmouseover = function () {
            convertButton.style.backgroundColor = "darkRed";
        };
        convertButton.onmouseleave = function () {
            convertButton.style.backgroundColor = "red";
        };

        convertButton.onclick = function () {
            window.open("https://www.y2mate.com/youtube/" + urlCut(document.URL), "_blank");
        };

        document.body.appendChild(convertButton);
        convertButton.appendChild(downloadText);
    }
    createButton();
})();
